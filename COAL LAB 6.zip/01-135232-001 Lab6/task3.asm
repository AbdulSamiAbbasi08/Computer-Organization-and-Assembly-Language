org 100h
.data

    str db 10,13, "Enter Number: $"
    str2 db 10,13, "Highest Number is: $" 
    higher db 0
    
.code

    mov cx, 10
    
  abc:
    LEA dx, str
    mov ah, 09h
    int 21h
    mov ah, 01
    int 21h
    
    cmp al, higher
    jg lbl
    jmp h
    
    
  lbl:
    mov higher, al
  h:     
    
    loop abc
    
    
    lea dx, str2
    mov ah, 09h
    int 21h
    mov dl, higher
    mov ah, 02
    int 21h     