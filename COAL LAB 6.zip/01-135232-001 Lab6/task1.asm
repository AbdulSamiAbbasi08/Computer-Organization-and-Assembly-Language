org 100h
.data

.code


mov cx,26
mov dl, 'z'
mov ah, 02
abc:
int 21h   
dec dl
loop abc
