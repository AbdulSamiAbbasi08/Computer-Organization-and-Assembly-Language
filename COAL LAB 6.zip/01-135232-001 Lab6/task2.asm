org 100h
.data

.code


    mov cx,10
    
    mov bl, 2
abc:
    mov ax,0
    mov al,cl
    
    div bl
    
    cmp ah, 0
    je lbl
    mov ah, 02
    mov dl,cl
    add dl,48
    int 21h   
    
lbl:
loop abc
