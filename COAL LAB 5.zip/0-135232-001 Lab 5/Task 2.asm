.model small

.data
marks db 72        
str1 DB 'Grade is:  A$'
str2 DB 'Grade is:  B$'
str3 DB 'Grade is:  C$'
str4 DB 'Grade is:  D$'
str5 DB 'Grade is:  F$'
msgInvalid DB 'Grade is Not Valid$'

.code
main proc
    mov ax, @data
    mov ds, ax

    mov AL, marks  
    cmp AL, 100
    ja invalid     

    cmp AL, 90
    jae GA

    cmp AL, 80
    jae GB

    cmp AL, 70
    jae GC

    cmp AL, 50
    jae GD

    cmp AL, 0
    jae GF

invalid:
    lea DX, msgInvalid
    mov AH, 09H
    int 21H
    jmp exit

GA:
    lea DX, str1
    mov AH, 09H
    int 21H
    JMP exit

GB:
    lea DX, str2
    mov AH, 09H
    int 21H
    JMP exit

GC:
    lea DX,str3
    mov AH, 09H
    int 21H
    JMP exit

GD:
    lea DX, str4
    mov AH, 09H
    int 21H
    JMP exit

GF:
    lea DX, str5
    mov AH, 09H
    int 21H

exit:
    mov AH, 4CH
    int 21H

main endp
end main