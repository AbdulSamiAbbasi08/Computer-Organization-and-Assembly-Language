include emu8086.inc
org 100h

.code
    mov bl, 1          
    mov dh, 3          

outer:
    cmp dh, 0
    je skip_spaces
    mov cl, dh

space_loop:
    putc ' '
    loop space_loop

skip_spaces:
    mov al, bl        

desc_loop:
    mov cl, al
    add cl, '0'
    putc cl            
    dec al
    jnz desc_loop

    mov al, 2         

asc_loop:
    cmp al, bl
    jg asc_done
    mov cl, al
    add cl, '0'
    putc cl           
    inc al
    jmp asc_loop

asc_done:
    printn ""          
    inc bl            
    dec dh            
    cmp bl, 5
    jne outer
    