.model small
.data
    msg1 db "Enter a single digit number: $"
    msg2 db 10,13,"Number is less than 5$"
    msg3 db 10,13,"Result: $"
.code
    mov ax,@data
    mov ds,ax
    lea dx,msg1
    mov ah,9
    int 21h
    mov ah,1
    int 21h
    sub al,48
    mov bl,al
    cmp bl,5
    jl lessthan
    test bl,1
    jnz odd
even:
    lea dx,msg3
    mov ah,9
    int 21h
    mov al,bl
    shr al,1
    add al,48
    mov dl,al
    mov ah,2
    int 21h
    jmp exit
odd:
    mov al,bl
    mov ah,0
    mov cl,2
    mul cl
    mov bl,al
    lea dx,msg3
    mov ah,9
    int 21h
    cmp bl,9
    jg twodigit
    mov dl,bl
    add dl,48
    mov ah,2
    int 21h
    jmp exit
twodigit:
    mov al,bl
    mov ah,0
    mov cl,10
    div cl
    mov bh,ah
    mov dl,al
    add dl,48
    mov ah,2
    int 21h
    mov dl,bh
    add dl,48
    mov ah,2
    int 21h
    jmp exit
lessthan:
    lea dx,msg2
    mov ah,9
    int 21h
exit:
    mov ah,4ch
    int 21h