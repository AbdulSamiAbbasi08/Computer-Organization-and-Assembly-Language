.model small
.data
    msg1 db "Enter 10 numbers: $"
    msg2 db 10,13,"Even count: $"
    msg3 db 10,13,"Odd count: $"
    msg4 db 10,13,"Even numbers are more$"
    msg5 db 10,13,"Odd numbers are more$"
    msg6 db 10,13,"Both are equal$"
    arr db 10 dup(?)
    even db 0
    odd db 0
.code
    mov ax,@data
    mov ds,ax
    lea dx,msg1
    mov ah,9
    int 21h
    mov si,0
    mov cx,10
input:
    mov ah,1
    int 21h
    sub al,48
    mov arr[si],al
    inc si
    loop input
    mov si,0
    mov cx,10
count:
    mov al,arr[si]
    mov ah,0
    mov bl,2
    div bl
    cmp ah,0
    jne isodd
    inc even
    jmp next
isodd:
    inc odd
next:
    inc si
    loop count
    lea dx,msg2
    mov ah,9
    int 21h
    mov dl,even
    add dl,48
    mov ah,2
    int 21h
    lea dx,msg3
    mov ah,9
    int 21h
    mov dl,odd
    add dl,48
    mov ah,2
    int 21h
    mov al,even
    cmp al,odd
    jg moreeven
    jl moreodd
    lea dx,msg6
    mov ah,9
    int 21h
    jmp exit
moreeven:
    lea dx,msg4
    mov ah,9
    int 21h
    jmp exit
moreodd:
    lea dx,msg5
    mov ah,9
    int 21h
exit:
    mov ah,4ch
    int 21h