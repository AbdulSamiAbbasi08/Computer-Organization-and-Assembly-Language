.model small
.data
    msg1 db "Enter a number (1-7): $"
    msg2 db 10,13,"Day: $"
    d1 db "Monday$"
    d2 db "Tuesday$"
    d3 db "Wednesday$"
    d4 db "Thursday$"
    d5 db "Friday$"
    d6 db "Saturday$"
    d7 db "Sunday$"
    inv db "Invalid Input$"
.code
    mov ax,@data
    mov ds,ax
    lea dx,msg1
    mov ah,9
    int 21h
    mov ah,1
    int 21h
    sub al,48
    mov bl,al
    lea dx,msg2
    mov ah,9
    int 21h
    cmp bl,1
    je mon
    cmp bl,2
    je tue
    cmp bl,3
    je wed
    cmp bl,4
    je thu
    cmp bl,5
    je fri
    cmp bl,6
    je sat
    cmp bl,7
    je sun
    jmp default
mon:
    lea dx,d1
    mov ah,9
    int 21h
    jmp exit
tue:
    lea dx,d2
    mov ah,9
    int 21h
    jmp exit
wed:
    lea dx,d3
    mov ah,9
    int 21h
    jmp exit
thu:
    lea dx,d4
    mov ah,9
    int 21h
    jmp exit
fri:
    lea dx,d5
    mov ah,9
    int 21h
    jmp exit
sat:
    lea dx,d6
    mov ah,9
    int 21h
    jmp exit
sun:
    lea dx,d7
    mov ah,9
    int 21h
    jmp exit
default:
    lea dx,inv
    mov ah,9
    int 21h
exit:
    mov ah,4ch
    int 21h
 