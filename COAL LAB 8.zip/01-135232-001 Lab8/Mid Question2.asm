.model small
.data
    msg1 db "Enter marks (press Enter to exit): $"
    msg2 db 10,13,"Grade: $"
    newl db 10,13,"$"
    ga db "A$"
    gb db "B$"
    gc db "C$"
    gf db "F$"
    inv db "Invalid input$"
.code
    mov ax,@data
    mov ds,ax
again:
    lea dx,newl
    mov ah,9
    int 21h
    lea dx,msg1
    mov ah,9
    int 21h
    mov ah,1
    int 21h
    cmp al,13
    je exit
    sub al,48
    mov bl,al
    cmp bl,0
    jl invalid
    cmp bl,9
    jg twod
    jmp check
twod:
    mov bh,bl
    mov ah,1
    int 21h
    cmp al,13
    je onedig
    sub al,48
    mov cl,al
    mov al,bh
    mov ah,0
    mov dl,10
    mul dl
    add al,cl
    mov bl,al
    cmp bl,10
    jg invalid
    jmp check
onedig:
    mov bl,bh
    jmp check
check:
    cmp bl,8
    jge gradea
    cmp bl,5
    jge gradeb
    cmp bl,3
    jge gradec
    jmp gradef
gradea:
    lea dx,msg2
    mov ah,9
    int 21h
    lea dx,ga
    mov ah,9
    int 21h
    jmp again
gradeb:
    lea dx,msg2
    mov ah,9
    int 21h
    lea dx,gb
    mov ah,9
    int 21h
    jmp again
gradec:
    lea dx,msg2
    mov ah,9
    int 21h
    lea dx,gc
    mov ah,9
    int 21h
    jmp again
gradef:
    lea dx,msg2
    mov ah,9
    int 21h
    lea dx,gf
    mov ah,9
    int 21h
    jmp again
invalid:
    lea dx,msg2
    mov ah,9
    int 21h
    lea dx,inv
    mov ah,9
    int 21h
    jmp again
exit:
    mov ah,4ch
    int 21h