.model small
.data
    msg1 db "Enter a number: $"
    msg2 db 10,13,"Enter second number: $"
    msg3 db 10,13,"Sum: $"
    msg4 db 10,13,"Multiplication: $"
.code
    mov ax,@data
    mov ds,ax
    lea dx,msg1
    mov ah,9
    int 21h
    mov ah,1
    int 21h
    sub al,48
    mov bl,al
    test bl,1
    jnz notdiv
div2:
    lea dx,msg2
    mov ah,9
    int 21h
    mov ah,1
    int 21h
    sub al,48
    add al,bl
    mov bl,al
    lea dx,msg3
    mov ah,9
    int 21h
    cmp bl,9
    jg twodigsum
    mov dl,bl
    add dl,48
    mov ah,2
    int 21h
    jmp exit
twodigsum:
    mov al,bl
    mov ah,0
    mov cl,10
    div cl
    mov bh,ah
    mov dl,al
    add dl,48
    mov ah,2
    int 21h
    mov dl,bh
    add dl,48
    mov ah,2
    int 21h
    jmp exit
notdiv:
    mov al,bl
    mov ah,0
    mov cl,2
    mul cl
    mov bl,al
    lea dx,msg4
    mov ah,9
    int 21h
    cmp bl,9
    jg twodigmul
    mov dl,bl
    add dl,48
    mov ah,2
    int 21h
    jmp exit
twodigmul:
    mov al,bl
    mov ah,0
    mov cl,10
    div cl
    mov bh,ah
    mov dl,al
    add dl,48
    mov ah,2
    int 21h
    mov dl,bh
    add dl,48
    mov ah,2
    int 21h
exit:
    mov ah,4ch
    int 21h