.model small
.data
    msg1 db "Enter 5 numbers: $"
    msg2 db 10,13,"Array in reverse: $"
    arr db 5 dup(?)
.code
    mov ax,@data
    mov ds,ax
    lea dx,msg1
    mov ah,9
    int 21h
    mov si,0
    mov cx,5
input:
    mov ah,1
    int 21h
    sub al,48
    mov arr[si],al
    inc si
    loop input
    lea dx,msg2
    mov ah,9
    int 21h
    mov si,4
    mov cx,5
display:
    mov dl,arr[si]
    add dl,48
    mov ah,2
    int 21h
    dec si
    loop display
    mov ah,4ch
    int 21h