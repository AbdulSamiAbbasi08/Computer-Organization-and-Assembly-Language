.model small
.data
    num db ?,?,?,?,?
    newl db 10,13,"$"
    prompt db "Enter 5 Numbers: $"
    des db "Number in Descending Order: $"
.code
    mov ax,@data
    mov ds,ax
    lea dx,prompt
    mov ah,9
    int 21h
    mov si,0
    mov cx,5
input:
    mov ah,1
    int 21h
    sub al,48
    mov num[si],al
    inc si
    loop input
    mov cx,4
outer:
    mov si,0
    mov bx,cx
inner:
    mov al,num[si]
    cmp al,num[si+1]
    jge noswap
    mov dl,num[si+1]
    mov num[si+1],al
    mov num[si],dl
noswap:
    inc si
    dec bx
    jnz inner
    loop outer
    lea dx,newl
    mov ah,9
    int 21h
    lea dx,des
    mov ah,9
    int 21h
    mov si,0
    mov cx,5
display:
    mov dl,num[si]
    add dl,48
    mov ah,2
    int 21h
    inc si
    loop display
    mov ah,4ch
    int 21h