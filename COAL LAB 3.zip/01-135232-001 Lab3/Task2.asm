.data
var1 db "Enter First Number: ","$"
var2 db "Enter First Number: ","$"
var3 db "Result: ","$"
newl db 13, 10, "$"


.code
main:
mov ax, @data
mov ds,ax
lea dx, var1


mov dx, offset var1
mov ah, 09h
int 21h




mov ah, 01h
int 21h
sub al, 48
mov bl, al


;newline
mov dx,offset newl
mov ah, 09h
int 21h

mov dx, offset var2
mov ah, 09h
int 21h

mov ah, 01h
int 21h
sub al, 48

;newline
mov dx,offset newl
mov ah, 09h
int 21h


mov dx, offset var3
mov ah, 09h
int 21h

mov ah, 0
mul bl

add al, 48

mov dl, al
mov ah, 02h
int 21h



mov ah, 4Ch
int 21h
end main
