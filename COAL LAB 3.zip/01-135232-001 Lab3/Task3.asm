.data
var1 db "Enter Dividen: ","$"
var2 db "Enter Divisor: ","$"
var3 db "Quotient: ","$"
var4 db "Remainder: ","$"
newl db 13, 10, "$"
res1 db ?
res2 db ?

.code
main:
mov ax, @data
mov ds,ax
lea dx, var1



mov dx, offset var2    ;enter divisor value
mov ah, 09h
int 21h

mov ah, 01h
int 21h
sub al, 48
mov bl, al 

;newline
mov dx,offset newl
mov ah, 09h
int 21h

mov dx, offset var1    ;enter divident value
mov ah, 09h
int 21h
mov ah, 01h
int 21h
sub al, 48
mov cl, al



;newline
mov dx,offset newl
mov ah, 09h
int 21h

mov al,cl
mov ah, 0
div bl     ;divide
add al, 48
add ah, 48
mov res1, al
mov res2, ah


mov dx, offset var3   ;Quetient
mov ah, 09h
int 21h

mov dl, res1
mov ah, 02h
int 21h


;newline
mov dx,offset newl
mov ah, 09h
int 21h

mov dx, offset var4   ;Remainder
mov ah, 09h
int 21h

mov dl, res2
mov ah, 02h
int 21h


mov ah, 4Ch
int 21h
end main 