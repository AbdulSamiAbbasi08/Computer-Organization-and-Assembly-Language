.data
var1 db 4
var2 db 5
newl db 10, 13, "$"


.code
main:
mov ax, @data
mov ds,ax
lea dx, var1

;add var1,48
;add var2,48

mov cl, var1
add cl, var2

mov dl, cl
add dl,48
mov ah, 02h
int 21h


mov dl, newl
mov ah, 02h
int 21h


mov dl, var2
sub dl, var1

add dl, 48
mov ah, 02h
int 21h




mov ah, 4Ch
int 21h
end main
