org 100h
jmp start

arr1:    dw 5, 3, 5, 7, 5, 2, 5      
arr2:    dw 9, 1, 2, 9, 4, 9, 8, 9   
msg1     db 'Call 1 replacements: $'  
msg2     db 'Call 2 replacements: $'  
newline  db 13, 10, '$'               


printAX:
    push ax                
    push bx
    push cx
    push dx

    mov  bx, 10            
    mov  cx, 0             

divLoop:
    mov  dx, 0             
    div  bx                
    push dx               
    inc  cx               
    cmp  ax, 0             
    jne  divLoop           

printDigits:
    pop  dx               
    add  dl, '0'          
    mov  ah, 02h           
    int  21h               
    loop printDigits     

    pop  dx                
    pop  cx
    pop  bx
    pop  ax
    ret                  


replaceVal:
  push bp             
  mov  bp, sp         
  sub  sp, 2           


  push cx         
  push dx             
  push si               

  
  mov  word [bp-2], 0  
  mov  si, [bp+8]      
  mov  cx, [bp+6]       
  mov  dx, [bp+4]       


scanloop:
  mov  ax, [si]        
  cmp  ax, dx           
  jne  noReplace        

  mov  word [si], 0    
  inc  word [bp-2]   


noReplace:
  add  si, 2         
  loop scanloop        


  mov  ax, [bp-2]       


  pop  si           
  pop  dx             
  pop  cx              

  mov  sp, bp          
  pop  bp              
  ret  6               


start:

  mov  ax, arr1
  push ax            
  mov  ax, 7
  push ax             
  mov  ax, 5
  push ax              
  call replaceVal      


  mov  ah, 09h      
  mov  dx, offset msg1
  int  21h              
  call printAX         
  mov  ah, 09h
  mov  dx, offset newline
  int  21h             

  
  mov  ax, arr2
  push ax               
  mov  ax, 8
  push ax              
  mov  ax, 9
  push ax               
  call replaceVal       


  mov  ah, 09h         
  mov  dx, offset msg2  
  int  21h              
  call printAX          
  mov  ah, 09h
  mov  dx, offset newline
  int  21h              

  mov  ax, 4ch        
  int  21h            