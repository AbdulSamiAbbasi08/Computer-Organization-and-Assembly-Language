; Practice Task 1 - copyArray subroutine using stack parameters
; Caller pushes: source address, destination address, element count
; Stack layout after prologue:
;   [BP+8] = source array address   (pushed first, deepest)
;   [BP+6] = destination address    (pushed second)
;   [BP+4] = element count          (pushed last, closest to return addr)
;   [BP+2] = return address
;   [BP+0] = saved old BP

org 100h
jmp start

;----------------------------------------------------------------
; Data: two source arrays and two empty destination arrays
;----------------------------------------------------------------
src1:   dw 10, 20, 30, 40, 50
dst1:   dw 0,  0,  0,  0,  0

src2:   dw 11, 22, 33
dst2:   dw 0,  0,  0

;================================================================
copyArray:
  ;---standard subroutine prologue----------------------------
  push bp           ; save old bp
  mov  bp, sp       ; make bp our reference point

  ;------------back up of registers being modified------------
  push ax
  push bx
  push cx
  push si
  push di

  ;---load parameters from stack via BP-----------------------
  mov  si, [bp+8]   ; [BP+8] holds the source array address
  mov  di, [bp+6]   ; [BP+6] holds the destination array address
  mov  cx, [bp+4]   ; [BP+4] holds the element count

;----------------------------------------------------------------
copyloop:
  mov  ax, [si]     ; load one word from source array
  mov  [di], ax     ; store that word into destination array
  add  si, 2        ; advance source pointer to next word
  add  di, 2        ; advance destination pointer to next word
  loop copyloop     ; decrement CX and repeat until CX = 0

;----------------------------------------------------------------
  pop di    ; Restore the values of
  pop si    ; backed up registers
  pop cx    ; in reverse order
  pop bx    ; of push
  pop ax

  pop  bp             ; restore old value of bp
  ret  6              ; return and discard 3 params x 2 bytes = 6

;================================================================
start:
  ;---first call: copy src1 (5 elements) into dst1------------
  mov  ax, src1
  push ax             ; push source array address
  mov  ax, dst1
  push ax             ; push destination array address
  mov  ax, 5
  push ax             ; push element count
  call copyArray      ; call subroutine

  ;---second call: copy src2 (3 elements) into dst2-----------
  mov  ax, src2
  push ax             ; push source array address
  mov  ax, dst2
  push ax             ; push destination array address
  mov  ax, 3
  push ax             ; push element count
  call copyArray      ; call subroutine again

  mov  ax, 0x4c00     ; terminate program
  int  0x21