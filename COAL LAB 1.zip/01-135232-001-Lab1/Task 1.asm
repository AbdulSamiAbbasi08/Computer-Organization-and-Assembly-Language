.data
msg db "Abdul Sami Abbasi", 010, "01-135232-001", 010, "BS(IT)","$"

.code 
main:
mov ax,@data
mov ds, ax
mov dx, offset msg

mov ah,9
int 21h     

mov ah,4ch
int 21h
end main
 
