.data
msg db "*", 0Ah, 013, "**", 0Ah,013, "***", 0Ah,013, "****", "$"

.code
main:
mov ax,@data
mov ds,ax
mov dx, offset msg


mov ah,9
int 21h

mov ah,4ch
int 21h
end main            