.data

.code
main:
mov dl,'a'
mov ah,02h
int 21h 


mov ah,4Ch
int 21h

end main: