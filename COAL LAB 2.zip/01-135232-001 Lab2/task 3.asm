.data
str    db "2 x 1 = ","$"
str2   db "2 x 2 = ","$"
str3   db "2 x 3 = ","$"
str4   db "2 x 4 = ","$"
str5   db "2 x 5 = ","$"
str6   db "2 x 6 = ","$"
str7   db "2 x 7 = ","$"
str8   db "2 x 8 = ","$"
str9   db "2 x 9 = ","$"
str10  db "2 x 10 = ","$"

r1 db 2
r2 db 4
r3 db 6
r4 db 8
r5 db 10
r6 db 12
r7 db 14
r8 db 16
r9 db 18
r10 db 20   

newline db 10,13,"$"


.code
main: 

;1

mov ax, @data
mov ds, ax
mov dx, offset str

mov ah,09h
int 21h

mov ah, 02h
mov dl, r1
add dl, 48
int 21h

mov dx, offset newline
mov ah, 09h
int 21h     



;2


mov ax, @data
mov ds, ax
mov dx, offset str2

mov ah,09h
int 21h

mov ah, 02h
mov dl, r2
add dl, 48
int 21h

mov dx, offset newline
mov ah, 09h
int 21h


;3

mov ax, @data
mov ds, ax
mov dx, offset str3

mov ah,09h
int 21h

mov ah, 02h
mov dl, r3
add dl, 48
int 21h

mov dx, offset newline
mov ah, 09h
int 21h 
 

;4

mov ax, @data
mov ds, ax
mov dx, offset str4

mov ah,09h
int 21h

mov ah, 02h
mov dl, r4
add dl, 48
int 21h

mov dx, offset newline
mov ah, 09h
int 21h 



;5

mov ax, @data
mov ds, ax
mov dx, offset str5

mov ah,09h
int 21h

mov ah, 02h
mov dl, 49
int 21h    

mov ah, 02h
mov dl, 48
int 21h

mov dx, offset newline
mov ah, 09h
int 21h 


;6

mov ax, @data
mov ds, ax
mov dx, offset str5

mov ah,09h
int 21h

mov ah, 02h
mov dl, 49
int 21h    

mov ah, 02h
mov dl, 50
int 21h

mov dx, offset newline
mov ah, 09h
int 21h 

;7

mov ax, @data
mov ds, ax
mov dx, offset str5

mov ah,09h
int 21h

mov ah, 02h
mov dl, 49
int 21h    

mov ah, 02h
mov dl, 52
int 21h

mov dx, offset newline
mov ah, 09h
int 21h 


;8

mov ax, @data
mov ds, ax
mov dx, offset str5

mov ah,09h
int 21h

mov ah, 02h
mov dl, 49
int 21h    

mov ah, 02h
mov dl, 54
int 21h

mov dx, offset newline
mov ah, 09h
int 21h 


;9


mov ax, @data
mov ds, ax
mov dx, offset str5

mov ah,09h
int 21h

mov ah, 02h
mov dl, 49
int 21h    

mov ah, 02h
mov dl, 56
int 21h

mov dx, offset newline
mov ah, 09h
int 21h  


;10

mov ax, @data
mov ds, ax
mov dx, offset str5

mov ah,09h
int 21h

mov ah, 02h
mov dl, 50
int 21h    

mov ah, 02h
mov dl, 48
int 21h

mov dx, offset newline
mov ah, 09h
int 21h  

;end

mov ah,4Ch
int 21h

end main
