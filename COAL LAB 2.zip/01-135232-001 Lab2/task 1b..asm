.data
msg db "Enter a Char: ", "$"
input db ?

.code
main:

mov ax, @data
mov ds, ax
mov dx, offset msg

mov ah,09h
int 21h

mov ah,01h
int 21h


mov input, al

mov dl, input
mov ah, 02h
int 21h




mov ah,4Ch
int 21h

end main