.data
msg1 db "Enter 1st Number: ","$"
msg2 db "Enter 2nd Number: ","$"
var1 db ?
var2 db ?
res db 0
newl db 10,13,"$"

.code
main:  
mov ax, @data
mov ds, ax
mov dx, offset msg1

mov ah, 09h
int 21h 

mov ah,01h
int 21h
mov var1,al

;newline
mov dx, offset newl
mov ah, 09h
int 21h  
 



mov dx, offset msg2

mov ah, 09h
int 21h 

mov ah,01h
int 21h
mov var2,al

;newline
mov dx, offset newl
mov ah, 09h
int 21h 


mov cl, var1
mov dl, var2

add res,cl
add res,dl

sub res,48
mov dl,res
mov ah,02h
int 21h
         


mov ah, 4Ch
int 21h
end main
