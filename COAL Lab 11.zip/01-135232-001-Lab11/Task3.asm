include 'emu8086.inc'
org 100h

jmp start

data dw 100 dup(?)
swapp db 0
msg1 db "Enter a Number: "
cnt dw ?

start:
    mov bx, 0
    mov dl, 0 ;counter

input:
    print 'Enter a Number: '    

    call scan_num
    
    cmp cx, 999
    je bubble  
    
    printn ''
    mov data[bx], cx
    add bx, 2
    
    jmp input


bubble:
    mov cnt, bx
    mov bx, 0
    mov swapp, 0
loop1:
    mov ax, [data + bx]
    cmp ax, [data + bx + 2]
    jbe no_swap
    call swap
    
no_swap:
    add bx, 2
    cmp bx, cnt
    jne loop1
    
    cmp swapp, 1
    je bubble 
    
    
quit:
    mov ah, 4Ch
    int 21h  


proc swap
    mov dx, [data+bx+2]
    mov [data+bx+2], ax
    mov [data+bx], dx
    mov swapp, 1
    ret
endp swap
    
    
    
DEFINE_PRINT_STRING
DEFINE_SCAN_NUM