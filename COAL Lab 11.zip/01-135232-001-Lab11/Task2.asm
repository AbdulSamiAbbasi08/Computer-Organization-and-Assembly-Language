include 'emu8086.inc'
org 100h

jmp start
    a db 5
    b db 8

start:

    add a, 48
    add b, 48
    print "Before Swap: "
    printn ''
    print 'a: '
    mov dl, a
    mov ah, 02h
    int 21h
    
    printn ''
    print 'b: '
    mov dl, b
    mov ah, 02h
    int 21h
   
  call swap
    printn '' 
    printn ''
    printn ''
    print "After Swap: "
    printn ''
    print 'a: '
    mov dl, a
    mov ah, 02h
    int 21h
    
    printn ''
    print 'b: '
    mov dl, b
    mov ah, 02h
    int 21h
exit:
    mov ah, 4ch
    int 21h
proc swap
   mov dl, a
   mov cl, b
   mov a, cl
   mov b, dl
    ret
endp swap  
    
   
    
    
DEFINE_PRINT_STRING
DEFINE_SCAN_NUM