include 'emu8086.inc'
org 100h

jmp start

    num dw ?
    isPrime db 1
    divv db 2

start:
    print "Enter a number: "
    
    call scan_num
    printn ""
    mov num, cx
    
call primecheck

exit:
    mov ah, 4ch
    int 21h

proc primecheck
    mov dl, 2
  loopp:
    mov ax, num
    div dl
    cmp ah, 0
    je not_prime
    
    mov ax, num
    div divv
    cmp al, dl
    je prime 
    
    inc dl
  jmp loopp
    
  prime: 
    print "Number is Prime"
    jmp endd
    
  not_prime: 
    PRINT "Number is not Prime"
    jmp endd
    
 endd:
    ret
endp primecheck  
    
   
    
    
DEFINE_PRINT_STRING
DEFINE_SCAN_NUM