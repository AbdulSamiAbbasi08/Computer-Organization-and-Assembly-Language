org 100h
.data
    arr dw 10,20,30,40,50,60,70,80,90,100
    
.code
    mov cx, 10
    mov si, 0
    
ppush:
    mov ax, arr[si]
    push ax
    add si, 2
    loop ppush
    
    mov cx, 10
    mov si, 0
    
ppop:
    pop ax
    mov arr[si], ax
    add si, 2
    loop ppop
   