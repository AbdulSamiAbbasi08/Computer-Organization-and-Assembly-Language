include 'emu8086.inc'

org 100h

.data
    count dw 0
    divisor dw 2
    input dw ?

.code

    mov cx, 10

inp:
    print "Enter a Number: "

    mov ah, 01
    int 21h
    sub al, 48

    mov ah, 0
    mov input, ax  

    printN ""

    div divisor 
    cmp dx, 0
   
    
    jne skip
    
    
    push input
    inc count

skip:
    loop inp

    mov cx, count

ppop:
    pop bx

    cmp bx, 6
    jge skipp
    mov dl, bl
    add dl, 48
    mov ah, 02
    int 21h

    print " was Stored in Stack"
    printN ""

skipp:
    loop ppop