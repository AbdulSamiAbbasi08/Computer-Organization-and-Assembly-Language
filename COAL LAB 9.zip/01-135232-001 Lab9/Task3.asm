include 'emu8086.inc'
org 100h

.data
    co dw 0
    val dw 0
    
    
.code
    
input:
    printn "Enter a Number or Press Enter to Skip: "
    
    mov ah, 01
    int 21h  
    
    cmp al, 13
    je skip
    
    sub al, 48
    mov ah, 0
    push ax
    inc co
    printn ""
    jmp input


skip:
    mov cx, co
    
greater:
    pop ax
    add ax, 48
    cmp ax, val
    jle abc
    mov val, ax
    
abc:
    loop greater
    
    printn "Greater Number is: "
    mov dx, val
    mov dh, 0
    mov ah, 2
    int 21h

    mov ah, 4ch
    int 21h        