include 'emu8086.inc'
org 100h

sumMacro MACRO p1,p2,p3,p4,p5
    LOCAL print1,print2,done
    mov al,p1
    add al,p2
    add al,p3
    add al,p4
    add al,p5
    mov ah,0
    cmp al,9
    jg print2
print1:
    mov dl,al
    add dl,48
    mov ah,2
    int 21h
    jmp done
print2:
    mov cl,10
    div cl
    mov bh,ah
    mov dl,al
    add dl,48
    mov ah,2
    int 21h
    mov dl,bh
    add dl,48
    mov ah,2
    int 21h
done:
ENDM

    mov cx,5
    mov bl,1
again:
    push cx
    PRINT "Sum: "
    cmp bl,1
    je call1
    cmp bl,2
    je call2
    cmp bl,3
    je call3
    cmp bl,4
    je call4
    cmp bl,5
    je call5
call1:
    sumMacro 1,2,3,4,5
    jmp next
call2:
    sumMacro 1,9,3,4,5
    jmp next
call3:
    sumMacro 1,2,8,4,5
    jmp next
call4:
    sumMacro 1,2,3,7,5
    jmp next
call5:
    sumMacro 1,2,3,4,6
next:
    PRINTN ""
    inc bl
    pop cx
    loop again

    mov ah,4ch
    int 21h