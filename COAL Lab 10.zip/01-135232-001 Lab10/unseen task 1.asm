include 'emu8086.inc'
org 100h

printPattern MACRO rows
    LOCAL outer,inner
    push cx
    push bx
    mov bl,1
    mov bh,rows
outer:
    push bx
    mov cl,bl
    mov ch,0
inner:
    PUTC '*'
    loop inner
    PRINTN ""
    pop bx
    inc bl
    dec bh
    cmp bh,0
    jne outer
    pop bx
    pop cx
ENDM

    PRINT "Enter number of rows (1-9): "
    mov ah,1
    int 21h
    sub al,48
    mov dl,al
    PRINTN ""
again:
    printPattern dl
    PRINTN ""
    PRINT "Press Enter to stop or any key to print again: "
    mov ah,1
    int 21h
    PRINTN ""
    cmp al,13
    jne again

    mov ah,4ch
    int 21h