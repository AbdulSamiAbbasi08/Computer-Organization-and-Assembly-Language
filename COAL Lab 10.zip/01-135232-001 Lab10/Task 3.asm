include 'emu8086.inc'
org 100h

printRow MACRO
    LOCAL pspace,pstar
    push cx
    mov cl,bl
    mov ch,0
    cmp cl,0
    je pstar
pspace:
    PUTC ' '
    loop pspace
pstar:
    mov cl,bh
    mov ch,0
pstarloop:
    PUTC '*'
    loop pstarloop
    PRINTN ""
    pop cx
ENDM

    mov cx,7
    mov bl,6
    mov bh,1
again:
    push cx
    printRow
    dec bl
    add bh,2
    pop cx
    loop again

    mov ah,4ch
    int 21h