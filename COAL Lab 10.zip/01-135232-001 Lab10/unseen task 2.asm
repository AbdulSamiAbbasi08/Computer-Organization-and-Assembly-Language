include 'emu8086.inc'
org 100h

printNum MACRO num
    LOCAL three,two,one,done
    push ax
    push bx
    push dx
    mov al,num
    mov ah,0
    cmp al,99
    jg three
    cmp al,9
    jg two
    jmp one
three:
    mov bl,100
    div bl
    mov bh,ah
    mov dl,al
    add dl,48
    mov ah,2
    int 21h
    mov al,bh
    mov ah,0
    mov bl,10
    div bl
    mov bh,ah
    mov dl,al
    add dl,48
    mov ah,2
    int 21h
    mov dl,bh
    add dl,48
    mov ah,2
    int 21h
    jmp done
two:
    mov bl,10
    div bl
    mov bh,ah
    mov dl,al
    add dl,48
    mov ah,2
    int 21h
    mov dl,bh
    add dl,48
    mov ah,2
    int 21h
    jmp done
one:
    mov dl,al
    add dl,48
    mov ah,2
    int 21h
done:
    pop dx
    pop bx
    pop ax
ENDM

start:
    PRINTN ""
    PRINT "Enter a number (1-3 digits): "
    mov ah,1
    int 21h
    cmp al,27
    je exit
    sub al,48
    mov bl,al

    mov ah,1
    int 21h
    cmp al,13
    je got1
    sub al,48
    mov cl,al

    mov ah,1
    int 21h
    cmp al,13
    je got2

    sub al,48
    mov dl,al
    mov al,bl
    mov ah,0
    mov bh,100
    mul bh
    mov bh,0
    mov bl,al
    mov al,cl
    mov ah,0
    mov cl,10
    mul cl
    add bl,al
    add bl,dl
    jmp show

got2:
    mov al,bl
    mov ah,0
    mov dl,10
    mul dl
    add al,cl
    mov bl,al
    jmp show

got1:
    jmp show

show:
    PRINTN ""
    PRINT "Number is: "
    printNum bl
    jmp start

exit:
    mov ah,4ch
    int 21h