include 'emu8086.inc'
org 100h

product MACRO
    LOCAL done1,done2,twodig
    mov al,bl
    mul cl
    mov ah,0
    cmp al,9
    jg twodig
    mov dl,al
    add dl,48
    mov ah,2
    int 21h
    jmp done2
twodig:
    push ax
    mov ah,0
    mov cl,10
    div cl
    mov bh,ah
    mov dl,al
    add dl,48
    mov ah,2
    int 21h
    mov dl,bh
    add dl,48
    mov ah,2
    int 21h
    pop ax
done2:
ENDM

start:
    PRINT "Enter 1st number: "
    mov ah,1
    int 21h
    sub al,48
    mov bl,al
    PRINTN ""
    PRINT "Enter 2nd number: "
    mov ah,1
    int 21h
    sub al,48
    mov cl,al
    PRINTN ""
    cmp bl,0
    jne notboth
    cmp cl,0
    je exit
notboth:
    PRINT "Product: "
    product
    PRINTN ""
    PRINTN ""
    jmp start
exit:
    mov ah,4ch
    int 21h
