.model small
.data
    num db 0
    num1 db 100
    num2 db 10
    temp db ?
    
    one db ?
    two db ?
    three db ?
    
    msg1 db "Enter 3 digits Value: ", "$" 
    msg2 db "The Number is: ", "$"
    unit db ?
    tens db ?
    hundreds db ?
    newl db 13,10,"$"
    
.code
main proc
    mov ax, @data
    mov ds, ax
    
    
;Hundred's Value
    LEA dx, msg1
    mov ah, 09h
    int 21h
    mov ah, 01h
    int 21h
    sub al, 48
    mov hundreds, al
    
    mov ah, 01h
    int 21h
    sub al, 48
    mov tens, al
    mov ah, 01h
    int 21h
    sub al, 48
    mov unit, al
    
;combining values
    mov ax,0
    mov al, hundreds
    mul num1
    mov num, al
    
    mov ax,0
    mov al, tens
    mul num2
    
    mov bl, num
    add bl, al
    add bl, unit   
    mov num, bl
    
;breaking number
    mov ax, 0
    mov al, num
    div num1
    mov one, al
    mov temp, ah
    
    mov ax, 0
    mov al, temp
    div num2
    mov two, al
    
    
;printing number  
    
    LEA dx, newl
    mov ah, 09h
    int 21h
    
    LEA dx, msg2
    mov ah, 09h
    int 21h
    
    mov dl, one
    add dl, 48
    mov ah, 02h
    int 21h
    
    mov dl, two
    add dl, 48
    mov ah, 02h
    int 21h
    
    mov dl, unit
    add dl, 48
    int 21h
    
                

;end main
mov ah, 4ch
int 21h
end main