.model small
.data
    num1 db -2
    num2 db 3
    
.code
main proc
    mov ax, @data
    mov ds, ax
    
;dividing negative number by neagtive number
    mov ax,0
    mov al, -17
    cbw
    mov bl, -5
    idiv bl

;dividing positive number by neagtive number
    mov ax,0
    mov al, 30
    cbw
    mov bl, -5
    idiv bl    

        

;end main
mov ah, 4ch
int 21h
end main