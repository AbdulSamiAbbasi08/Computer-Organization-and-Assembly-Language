.model small
.data
    num1 db -2
    num2 db 3
    
.code
main proc
    mov ax, @data
    mov ds, ax
    
;signed Multiplication   

    mov al, num1
    mov bl, num2
    imul bl
    
    
;dividing result by signed number
    mov bl,-4
    cbw
    idiv bl
        

;end main
mov ah, 4ch
int 21h
end main